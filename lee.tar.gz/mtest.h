#include<stdio.h>

void InFoo();
void InBoo();
void InBar();
