#include "mtest.h"

void main(){
	InFoo();
	InBoo();
	InBar();
}
