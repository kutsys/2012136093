#include"mtest.h"

void InBoo(){
	printf("Hello, I'm Boo\n");
} 
