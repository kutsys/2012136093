#include"mtest.h"

void InFoo(){
	printf("Hello, I'm foo\n");
}
