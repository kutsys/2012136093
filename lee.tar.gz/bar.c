#include"mtest.h"

void InBar(){
	printf("Hello, I'm Bar\n");
}
